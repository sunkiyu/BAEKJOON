from flask import Flask
from flask import render_template
from flask import request
import jsonify
import json
app = Flask(__name__)

@app.route("/", methods=['GET', 'POST'])
@app.route("/user", methods=['GET', 'POST'])
def post():
	if(request.method =='GET'):
    		return render_template('index.html')
	elif(request.method == 'POST'):
		value = request.form['input']
		return render_template('welcome.html', name=value)

@app.route("/reporter", methods=['POST','GET'])
def reporter():
	data = {"data":[]}
	with open('rule_list.json') as file:
		ruledata = json.load(file)
		for fileInfo in ruledata['data']:
			with open(fileInfo['filename']) as jsonfile:
				filedata = json.load(jsonfile)
				filedata['parsing_rule']['search'] = filedata['parsing_rule']['search'].replace('<','&lt;')
				fileInfo['filedata'] = filedata
				data['data'].append(fileInfo)
	file.close()
	return data

if __name__ == "__main__":
	app.run()