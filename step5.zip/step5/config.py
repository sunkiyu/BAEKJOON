import sys
import rules

PARSING_RULES = [
      sys.modules[module].PARSING_RULES for module in sys.modules if module.find('ruels.') != -1
]
