import json
import ruels.BModule
import ruels.CModule
import ruels.AModule

PARSING_RULES = []

files = ['JAModule.json', 'JBModule.json']

for file in files:
    path = 'ruels/' + file
    try:
        f = open(path)
        json_object = json.load(f)
        PARSING_RULES.append(json.dumps(json_object))
    except:
        print('file does not exist')


print(PARSING_RULES)