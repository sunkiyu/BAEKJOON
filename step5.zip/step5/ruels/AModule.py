PARSING_RULES = [{
    "category":"Btest",
    "search":r"Btest",
}]