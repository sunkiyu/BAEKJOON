PARSING_RULES = [{
    "category":"test",
    "search":r"test",
}]